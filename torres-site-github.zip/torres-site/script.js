// Navegación móvil
const navToggle = document.getElementById('navToggle');
const nav = document.getElementById('nav');
navToggle?.addEventListener('click', () => {
  nav?.classList.toggle('show');
});

// Año dinámico en el footer
document.getElementById('year').textContent = new Date().getFullYear();

// Simulación de envío de formulario
window.fakeSubmit = function() {
  const status = document.getElementById('formStatus');
  status.textContent = '¡Gracias! Hemos recibido tu mensaje.';
  setTimeout(() => { status.textContent = ''; }, 4000);
};

// Desplazamiento suave para enlaces internos
for (const link of document.querySelectorAll('a[href^="#"]')) {
  link.addEventListener('click', function (e) {
    const targetId = this.getAttribute('href');
    if (targetId.length > 1) {
      e.preventDefault();
      document.querySelector(targetId)?.scrollIntoView({ behavior: 'smooth' });
      nav?.classList.remove('show');
    }
  });
}
