# Plantilla de página web (estática)

Una plantilla básica, moderna y responsive en HTML, CSS y JavaScript.

## Estructura
- `index.html` — Estructura del contenido.
- `styles.css` — Estilos visuales.
- `script.js` — Interactividad mínima (menú móvil, scroll suave y estado del formulario).

## Cómo usar
1. Abre `index.html` en tu navegador.
2. Edita textos, imágenes y colores a tu gusto.
3. Para publicar:
   - **GitHub Pages**: sube el contenido a un repositorio y activa Pages.
   - **Netlify/Vercel**: arrastra la carpeta o conecta tu repo.
   - **Servidor propio**: sube los archivos por SFTP/FTP.

## Personalización rápida
- **Marca**: cambia el texto del enlace con clase `.brand` en el encabezado.
- **Colores**: ajusta variables CSS en `:root` (por ejemplo `--brand`, `--accent`).
- **Secciones**: duplica bloques `.section` y actualiza los IDs y enlaces del menú.

## Accesibilidad
- Contraste elevado, foco visible y roles básicos para estados.

---
Creado automáticamente por M365 Copilot.


## Publicar en GitHub Pages

1. Crea un repositorio en GitHub (ej.: `torres-site`).
2. Sube todos los archivos de esta carpeta a la rama `main`.
3. Ve a **Settings → Pages** y en **Build and deployment** selecciona **GitHub Actions**.
4. Se ejecutará el workflow `Deploy to GitHub Pages`.
5. Al finalizar, tu sitio estará disponible en la URL que muestre el job (por ej. `https://usuario.github.io/torres-site/`).

> Nota: el archivo `.nojekyll` evita el procesamiento de Jekyll.
